# air-pollution-indicator

## This website detects, the user location automatically and display the output in the main window.

![image](https://user-images.githubusercontent.com/57454462/181349083-c0b644f9-648a-4a7f-be21-6060f4603a36.png)

